export class GetBookmarkDto{
    url?:string;
    description?:string;
}
//ba ? optional mikonim

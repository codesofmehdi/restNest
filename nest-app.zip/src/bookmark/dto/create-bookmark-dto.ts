export class CreateBookmarkDto{
    url:string;
    description:string;
}
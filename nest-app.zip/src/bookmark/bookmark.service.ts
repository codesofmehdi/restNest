import { GetBookmarkDto } from './dto/get-bookmark-dto';
import { CreateBookmarkDto } from './dto/create-bookmark-dto';
import { Bookmark } from './bookmark.model';
import { Injectable } from '@nestjs/common';
import { v4 as uuidv4 } from 'uuid';


@Injectable()
export class BookmarkService {
    //ارایه بوکمارک
    //دیگه به این ارایه اولیه نیاز نداریم چون برنامه خودش قابلیت پست داره
    /*private bookmarks:Bookmark[] =[
    {
        id:uuidv4(),
        url:'http://google.com',
        description:'Mehdi favorite website'
    }
    ];*/
    private bookmarks:Bookmark[] =[];



    // متودی که پیشوند ندارد پابلیک هست
    findAll():Bookmark[]{
        return this.bookmarks;
    }
    
    findById(id:string):Bookmark{
        //براساس ایدی یکرکورد برگردنیم
        return this.bookmarks.find((bookmark)=>bookmark.id===id);
    }
    //find by url or description
    find(getBookmarkDto:GetBookmarkDto):Bookmark[]{
       let bookmarks = this.findAll();
       const{url,description}=getBookmarkDto;
       if(url){
        bookmarks = bookmarks.filter(
            (bookmark)=>bookmark.url.toLowerCase().includes(url)
            );
            // (bookmark)=>bookmark.url===url)
       }
       if(description){
        bookmarks =  bookmarks.filter(
            (bookmark)=>bookmark.description.toLowerCase().includes(description)
            );
       }
           
       return bookmarks;
     }

    /*
    //create bookmark
    createBookmark(url:string,description:string){
        const bookmark:Bookmark={
            id:uuidv4(),
            url,
            description
        };
        this.bookmarks.push(bookmark);
        return bookmark;//چون نیاز نمیشه برای گرفتن ایتم تازه ساخته شده مجدد دستور ارسال کنیم
    }*/
      //create bookmark
    createBookmark(createBookmarkDto:CreateBookmarkDto):Bookmark{
        const{url,description} = createBookmarkDto;
        const bookmark:Bookmark={
            id:uuidv4(),
            url,
            description
        };
        this.bookmarks.push(bookmark);
        return bookmark;//چون نیاز نمیشه برای گرفتن ایتم تازه ساخته شده مجدد دستور ارسال کنیم
    }
    deleteBookmark(id:string):void{
        this.bookmarks= this.bookmarks.filter((bookmark)=>bookmark.id!==id);
    }
    updateBookmarkDescription(id:string,description:string):Bookmark{
        const bookmark = this.findById(id);
        bookmark.description=description;
        return bookmark;
    }
}

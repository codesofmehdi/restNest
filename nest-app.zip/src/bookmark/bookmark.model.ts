export interface Bookmark{
    id:string;
    url:string;
    description:string;
}
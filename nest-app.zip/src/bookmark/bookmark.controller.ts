import { Bookmark } from './bookmark.model';
import { Controller, Get, Post,Body, Param, Query, Delete, Patch } from '@nestjs/common';
import { BookmarkService } from './bookmark.service';
import { CreateBookmarkDto } from './dto/create-bookmark-dto';
import { GetBookmarkDto } from './dto/get-bookmark-dto';

@Controller('bookmarks')
export class BookmarkController {
    constructor(private bookmarkService:BookmarkService){
    }
    
    //GET http://localhost:3000/bookmarks
    @Get()
    find(@Query() getBookmarkDto:GetBookmarkDto):Bookmark[]{
        if(Object.keys(getBookmarkDto).length){
            return this.bookmarkService.find(getBookmarkDto);
        }
        return this.bookmarkService.findAll();
    }
    
    //برای هندل کردن Route parameter ها باید از دو نقطه استفاده کنیم
    @Get('/:id')
    findById(@Param('id') id:string):Bookmark{
        return this.bookmarkService.findById(id);
    }

    
    /*@Post()
    createBookmark(@Body('url') url,@Body('description') description):Bookmark{
        //اینجا به بادی ریکوئست نیاز داریم
        //که دو راه داریم یا بادی کامل بدیم که ممکنه پارمتر اضافی داشته باشه و راه دوم اینکه 
        //مثلا @Body() body
        //console.table(body);
        //console.log(body)
        
        //فقط اون متغیرهایی که نیاز داریم از بادی برداریم
        //مثلا @Body('url') url
       return  this.bookmarkService.createBookmark(url,description);
    }*/
    @Post()
    createBookmark(@Body() createBookmarkDto:CreateBookmarkDto):Bookmark{
        return  this.bookmarkService.createBookmark(createBookmarkDto);
    }
    @Delete('/:id')
    deleteBookmark(@Param('id') id:string):void{
        return this.bookmarkService.deleteBookmark(id);
    }
    //
    @Patch('/:id/description')
    updateBookmarkDescription(@Param('id') id:string,@Body('description') description:string):Bookmark{
        return this.bookmarkService.updateBookmarkDescription(id,description);
    }

}
